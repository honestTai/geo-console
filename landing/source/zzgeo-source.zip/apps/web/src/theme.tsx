import { App as AntdApp, ConfigProvider } from "antd";
import zhCN from "antd/locale/zh_CN";
import dayjs from "dayjs";
import "dayjs/locale/zh-cn";
import type { ReactNode } from "react";
import { BrandLoadingMark } from "./ui/BrandLoading";

dayjs.locale("zh-cn");

/** 与 styles.css :root 保持一致的品牌与中性色。 */
export const brandColor = "#155dfb";
export const inkColor = "#111827";
export const lineColor = "#e5e7eb";
export const sidebarColor = "#ffffff";

export function ThemeProvider({ children }: { children: ReactNode }) {
	return (
		<ConfigProvider
			locale={zhCN}
			spin={{ indicator: <BrandLoadingMark /> }}
			button={{ loadingIcon: <BrandLoadingMark inline /> }}
			select={{ loadingIcon: <BrandLoadingMark inline /> }}
			theme={{
				token: {
					colorPrimary: brandColor,
					colorLink: "#1d4ed8",
					colorLinkHover: brandColor,
					colorText: inkColor,
					colorTextSecondary: "#475467",
					colorTextTertiary: "#667085",
					colorBorder: lineColor,
					colorBorderSecondary: "#eef0f3",
					colorBgLayout: "#f9fafb",
					borderRadius: 6,
					borderRadiusLG: 8,
					borderRadiusSM: 4,
					controlHeight: 40,
					controlHeightSM: 28,
					controlHeightLG: 42,
					fontSize: 14,
					fontFamily: "Inter, PingFang SC, Microsoft YaHei, sans-serif",
					boxShadowSecondary: "0 8px 24px rgba(16, 24, 40, 0.10)",
				},
				components: {
					Spin: { dotSize: 32, dotSizeSM: 20, dotSizeLG: 48 },
					Layout: { headerBg: sidebarColor, siderBg: sidebarColor, bodyBg: "#f9fafb" },
					Button: {
						fontWeight: 600,
						paddingInline: 14,
						defaultBorderColor: "#c9cfd8",
						defaultShadow: "none",
						primaryShadow: "none",
					},
					Card: { paddingLG: 24, headerFontSize: 16, headerHeight: 60 },
					Table: {
						headerBg: "#fafbfc",
						headerColor: "#475467",
						cellPaddingBlock: 16,
						cellPaddingInline: 20,
						rowHoverBg: "#f8f9fb",
					},
					Form: { itemMarginBottom: 16, labelColor: "#475467", labelFontSize: 13 },
					Input: { paddingInline: 12 },
					Select: { optionSelectedBg: "#eff6ff" },
					Tag: { defaultBg: "#f2f4f7", defaultColor: "#475467" },
					Tabs: { titleFontSize: 14, horizontalItemPadding: "10px 0", horizontalMargin: "0 0 20px 0" },
					Modal: { titleFontSize: 16 },
					Drawer: { paddingLG: 20 },
					Statistic: { titleFontSize: 12.5, contentFontSize: 26 },
					Descriptions: { labelBg: "#f8f9fb" },
					Timeline: { dotBorderWidth: 2 },
					Steps: { iconSize: 26 },
					Alert: { defaultPadding: "10px 14px" },
				},
			}}
		>
			<AntdApp>{children}</AntdApp>
		</ConfigProvider>
	);
}
