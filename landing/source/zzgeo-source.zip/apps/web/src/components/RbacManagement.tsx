import { IconPlus, IconTrash } from "@tabler/icons-react";
import { Alert, App, Checkbox, Input, List, Popconfirm, Switch, Table, Tabs, Tree, Typography } from "antd";
import { type ReactNode, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Button } from "../access";
import { api, post, put } from "../api";
import {
	DEFAULT_PAGE_SIZE,
	type ManagedUser,
	type Paginated,
	type PermissionRecord,
	type ProjectSummary,
	type RoleRecord,
	type UserIdentity,
} from "../types";
import { Pagination } from "../ui/primitives";
import { AuthorizationConfiguration } from "./AuthorizationConfiguration";
import { Page } from "./Page";
import "./RbacManagement.css";

type PermissionTreeNode = {
	key: string;
	title: ReactNode;
	children?: PermissionTreeNode[];
	selectable?: false;
};

/** 菜单 → 按钮权限树：勾选菜单带上其下全部按钮；勾选按钮自动带上所属菜单；取消菜单同时取消按钮。 */
export function PermissionChecklist({
	permissions,
	selected,
	onChange,
}: {
	permissions: PermissionRecord[];
	selected: string[];
	onChange(keys: string[]): void;
}) {
	const { tree, parentOf, childrenOf, groupKeys } = useMemo(() => {
		const pages = permissions.filter((permission) => permission.kind === "page");
		const actions = permissions.filter((permission) => permission.kind === "action");
		const parentOf = new Map<string, string>();
		const childrenOf = new Map<string, string[]>();
		const orphanActions: PermissionRecord[] = [];
		for (const action of actions) {
			const parent =
				action.parent_key && pages.some((page) => page.key === action.parent_key) ? action.parent_key : null;
			if (!parent) {
				orphanActions.push(action);
				continue;
			}
			parentOf.set(action.key, parent);
			childrenOf.set(parent, [...(childrenOf.get(parent) ?? []), action.key]);
		}
		const groups = new Map<string, PermissionRecord[]>();
		for (const page of pages) groups.set(page.group_label, [...(groups.get(page.group_label) ?? []), page]);
		const groupKeys = new Map<string, string[]>();
		const tree: PermissionTreeNode[] = [...groups.entries()].map(([group, items]) => {
			const keys = items.flatMap((page) => [page.key, ...(childrenOf.get(page.key) ?? [])]);
			groupKeys.set(`group:${group}`, keys);
			return {
				key: `group:${group}`,
				selectable: false,
				title: <span className="permission-tree-group">{group}</span>,
				children: items.map((page) => ({
					key: page.key,
					selectable: false,
					title: (
						<span className="permission-tree-page">
							{page.label}
							<Typography.Text type="secondary">菜单</Typography.Text>
						</span>
					),
					children: (childrenOf.get(page.key) ?? []).map((actionKey) => {
						const action = actions.find((item) => item.key === actionKey);
						return {
							key: actionKey,
							selectable: false,
							title: (
								<span className="permission-tree-action">
									{action?.label ?? actionKey}
									<Typography.Text type="secondary">按钮</Typography.Text>
								</span>
							),
						};
					}),
				})),
			};
		});
		if (orphanActions.length) {
			const keys = orphanActions.map((action) => action.key);
			groupKeys.set("group:其他功能", keys);
			tree.push({
				key: "group:其他功能",
				selectable: false,
				title: <span className="permission-tree-group">其他功能</span>,
				children: orphanActions.map((action) => ({
					key: action.key,
					selectable: false,
					title: (
						<span className="permission-tree-action">
							{action.label}
							<Typography.Text type="secondary">按钮</Typography.Text>
						</span>
					),
				})),
			});
		}
		return { tree, parentOf, childrenOf, groupKeys };
	}, [permissions]);
	const allKeys = permissions.map((permission) => permission.key);
	const selectedSet = new Set(selected.filter((key) => allKeys.includes(key)));
	const dormantKeys = selected.filter((key) => !allKeys.includes(key));
	// 分组节点：全部子项选中时勾选。
	const checkedKeys = [
		...selectedSet,
		...[...groupKeys.entries()]
			.filter(([, keys]) => keys.length && keys.every((key) => selectedSet.has(key)))
			.map(([key]) => key),
	];
	const halfCheckedKeys = [
		...[...childrenOf.entries()]
			.filter(
				([page, children]) =>
					selectedSet.has(page) &&
					children.some((key) => selectedSet.has(key)) &&
					!children.every((key) => selectedSet.has(key)),
			)
			.map(([page]) => page),
		...[...groupKeys.entries()]
			.filter(([key, keys]) => !checkedKeys.includes(key) && keys.some((item) => selectedSet.has(item)))
			.map(([key]) => key),
	];
	function toggle(key: string, checked: boolean) {
		const next = new Set(selectedSet);
		const apply = (target: string, on: boolean) => {
			if (on) {
				next.add(target);
				const parent = parentOf.get(target);
				if (parent) next.add(parent);
			} else {
				next.delete(target);
				for (const child of childrenOf.get(target) ?? []) next.delete(child);
			}
		};
		if (key.startsWith("group:")) for (const item of groupKeys.get(key) ?? []) apply(item, checked);
		else {
			apply(key, checked);
			if (checked) for (const child of childrenOf.get(key) ?? []) next.add(child);
		}
		onChange([...dormantKeys, ...allKeys.filter((item) => next.has(item))]);
	}
	const total = allKeys.length;
	return (
		<div className="permission-tree">
			<div className="permission-tree-toolbar">
				<span>
					已选 {selectedSet.size}/{total}
					{dormantKeys.length ? ` · ${dormantKeys.length} 项权限被机构上限暂时禁用，保留角色配置` : ""}
				</span>
				<Button variant="link" size="small" onClick={() => onChange([...dormantKeys, ...allKeys])}>
					全选
				</Button>
				<Button variant="link" size="small" onClick={() => onChange([])}>
					清空
				</Button>
			</div>
			<Tree
				checkable
				checkStrictly
				selectable={false}
				defaultExpandAll
				blockNode
				treeData={tree}
				checkedKeys={{ checked: checkedKeys, halfChecked: halfCheckedKeys }}
				onCheck={(_, info) => {
					const key = String(info.node.key);
					toggle(key, info.checked);
				}}
			/>
		</div>
	);
}

export function RbacManagement({ user, onOpenMembers }: { user: UserIdentity; onOpenMembers?: () => void }) {
	const { message } = App.useApp();
	const [tab, setTab] = useState<"organization" | "roles" | "users" | "configuration">("organization");
	const [permissions, setPermissions] = useState<PermissionRecord[]>([]);
	const [organizationKeys, setOrganizationKeys] = useState<string[]>([]);
	const [rolesPage, setRolesPage] = useState<Paginated<RoleRecord>>({
		items: [],
		page: 1,
		pageSize: DEFAULT_PAGE_SIZE,
		total: 0,
		totalPages: 1,
	});
	const [usersPage, setUsersPage] = useState<Paginated<ManagedUser>>({
		items: [],
		page: 1,
		pageSize: DEFAULT_PAGE_SIZE,
		total: 0,
		totalPages: 1,
	});
	const [projectsPage, setProjectsPage] = useState<Paginated<ProjectSummary>>({
		items: [],
		page: 1,
		pageSize: DEFAULT_PAGE_SIZE,
		total: 0,
		totalPages: 1,
	});
	const [roleDraft, setRoleDraft] = useState<{
		id: string | null;
		name: string;
		description: string;
		permissionKeys: string[];
	}>({
		id: null,
		name: "",
		description: "",
		permissionKeys: [],
	});
	const [selectedUser, setSelectedUser] = useState<ManagedUser | null>(null);
	const [userRoleIds, setUserRoleIds] = useState<string[]>([]);
	const [allProjects, setAllProjects] = useState(true);
	const [projectIds, setProjectIds] = useState<string[]>([]);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState<string | null>(null);

	const currentPages = useRef({ roles: 1, users: 1, projects: 1 });
	const loadCatalog = useCallback(async () => {
		const result = await api<{ permissions: PermissionRecord[]; organizationPermissionKeys: string[] }>(
			"/api/rbac/catalog",
		);
		setPermissions(result.permissions);
		setOrganizationKeys(result.organizationPermissionKeys);
	}, []);
	const loadRoles = useCallback(
		async (page = currentPages.current.roles) => {
			const result = await api<Paginated<RoleRecord>>(`/api/rbac/roles?page=${page}&pageSize=${rolesPage.pageSize}`);
			currentPages.current.roles = result.page;
			setRolesPage(result);
		},
		[rolesPage.pageSize],
	);
	const loadUsers = useCallback(
		async (page = currentPages.current.users) => {
			const result = await api<Paginated<ManagedUser>>(`/api/users?page=${page}&pageSize=${usersPage.pageSize}`);
			currentPages.current.users = result.page;
			setUsersPage(result);
		},
		[usersPage.pageSize],
	);
	const loadProjectsForScope = useCallback(
		async (page = currentPages.current.projects) => {
			const result = await api<Paginated<ProjectSummary>>(
				`/api/projects?page=${page}&pageSize=${projectsPage.pageSize}`,
			);
			currentPages.current.projects = result.page;
			setProjectsPage(result);
		},
		[projectsPage.pageSize],
	);
	const reload = useCallback(async () => {
		setError(null);
		try {
			await Promise.all([loadCatalog(), loadRoles(), loadUsers(), loadProjectsForScope()]);
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : "权限配置加载失败");
		}
	}, [loadCatalog, loadProjectsForScope, loadRoles, loadUsers]);
	useEffect(() => {
		void reload();
	}, [reload]);
	const rolePermissions = permissions.filter(
		(permission) => !permission.system_only && organizationKeys.includes(permission.key),
	);

	async function saveOrganizationPermissions() {
		setBusy(true);
		setError(null);
		try {
			await put(`/api/organizations/${user.organizationId}/permissions`, { permissionKeys: organizationKeys });
			message.success("机构授权已保存");
			await reload();
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : "机构授权保存失败");
		} finally {
			setBusy(false);
		}
	}

	async function saveRole() {
		setBusy(true);
		setError(null);
		try {
			const payload = {
				name: roleDraft.name,
				description: roleDraft.description || null,
				permissionKeys: roleDraft.permissionKeys,
			};
			if (roleDraft.id) await put(`/api/rbac/roles/${roleDraft.id}`, payload);
			else await post("/api/rbac/roles", payload);
			message.success("角色已保存");
			setRoleDraft({ id: null, name: "", description: "", permissionKeys: [] });
			await loadRoles(1);
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : "角色保存失败");
		} finally {
			setBusy(false);
		}
	}

	function editUserAccess(member: ManagedUser) {
		setSelectedUser(member);
		setUserRoleIds(member.roles.map((role) => role.id));
		setAllProjects(member.all_projects);
		setProjectIds(member.project_ids);
	}

	async function saveUserAccess() {
		if (!selectedUser) return;
		setBusy(true);
		setError(null);
		try {
			await put(`/api/users/${selectedUser.id}/access`, { roleIds: userRoleIds, allProjects, projectIds });
			message.success("用户授权已保存");
			await loadUsers();
			setSelectedUser(null);
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : "用户授权保存失败");
		} finally {
			setBusy(false);
		}
	}

	async function deleteRole(role: RoleRecord) {
		setError(null);
		try {
			await api(`/api/rbac/roles/${role.id}`, { method: "DELETE" });
			message.success(`角色「${role.name}」已删除`);
			await loadRoles();
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : "角色删除失败");
		}
	}

	return (
		<Page
			className="rbac-management"
			eyebrow="权限配置"
			title="角色与授权"
			description="权限 = 机构授权上限 ∩ 角色权限并集，再按客户范围收窄。"
		>
			{error && <Alert type="error" showIcon title={error} />}
			<Tabs
				activeKey={tab}
				onChange={(key) => setTab(key as typeof tab)}
				items={[
					{
						key: "configuration",
						label: "授权引擎",
						children: <AuthorizationConfiguration permissions={permissions} onChanged={reload} />,
					},
					{
						key: "organization",
						label: "机构授权",
						children: (
							<div className="rbac-section">
								<header>
									<div>
										<h3>{user.organizationName}</h3>
										<p>超管决定该机构最多可使用的页面和功能；角色不能越过这里的上限。</p>
									</div>
									<Button busy={busy} onClick={() => void saveOrganizationPermissions()}>
										保存机构授权
									</Button>
								</header>
								<PermissionChecklist
									permissions={permissions.filter((permission) => !permission.system_only)}
									selected={organizationKeys}
									onChange={setOrganizationKeys}
								/>
							</div>
						),
					},
					{
						key: "roles",
						label: "角色权限",
						children: (
							<div className="rbac-split">
								<section className="rbac-list">
									<header>
										<h3>机构角色</h3>
										<Button
											variant="secondary"
											icon={<IconPlus size={16} />}
											onClick={() => setRoleDraft({ id: null, name: "", description: "", permissionKeys: [] })}
										>
											新建角色
										</Button>
									</header>
									<List
										size="small"
										className="rbac-role-list"
										dataSource={rolesPage.items}
										renderItem={(role) => (
											<List.Item
												className={roleDraft.id === role.id ? "active" : undefined}
												onClick={() =>
													setRoleDraft({
														id: role.id,
														name: role.name,
														description: role.description ?? "",
														permissionKeys: role.permission_keys,
													})
												}
												actions={
													role.is_system
														? undefined
														: [
																<Popconfirm
																	key="delete"
																	title={`删除角色「${role.name}」？`}
																	okText="删除"
																	cancelText="取消"
																	onConfirm={() => void deleteRole(role)}
																>
																	<span>
																		<Button variant="ghost" icon={<IconTrash size={15} />}>
																			删除
																		</Button>
																	</span>
																</Popconfirm>,
															]
												}
											>
												<List.Item.Meta
													title={role.name}
													description={`${role.user_count} 位用户 · ${role.permission_keys.length} 项权限`}
												/>
											</List.Item>
										)}
									/>
									<Pagination
										{...rolesPage}
										onPage={(page) =>
											void loadRoles(page).catch((reason) =>
												setError(reason instanceof Error ? reason.message : "角色加载失败"),
											)
										}
									/>
								</section>
								<section className="role-editor">
									<h3>{roleDraft.id ? "编辑角色" : "新建角色"}</h3>
									<Input
										value={roleDraft.name}
										onChange={(event) => setRoleDraft({ ...roleDraft, name: event.target.value })}
										placeholder="角色名称"
									/>
									<Input.TextArea
										value={roleDraft.description}
										onChange={(event) => setRoleDraft({ ...roleDraft, description: event.target.value })}
										placeholder="角色说明"
										rows={3}
									/>
									<PermissionChecklist
										permissions={rolePermissions}
										selected={roleDraft.permissionKeys}
										onChange={(permissionKeys) => setRoleDraft({ ...roleDraft, permissionKeys })}
									/>
									<Button busy={busy} disabled={!roleDraft.name.trim()} onClick={() => void saveRole()}>
										保存角色
									</Button>
								</section>
							</div>
						),
					},
					{
						key: "users",
						label: "用户与客户范围",
						children: (
							<div className="rbac-split">
								<section className="rbac-list">
									<header>
										<h3>机构用户</h3>
										{onOpenMembers && (
											<Button variant="secondary" size="small" onClick={onOpenMembers}>
												添加 / 恢复成员
											</Button>
										)}
									</header>
									<List
										size="small"
										className="rbac-role-list"
										dataSource={usersPage.items}
										renderItem={(member) => (
											<List.Item
												className={selectedUser?.id === member.id ? "active" : undefined}
												onClick={member.is_super_admin ? undefined : () => editUserAccess(member)}
											>
												<List.Item.Meta
													title={member.display_name}
													description={member.roles.map((role) => role.name).join("、") || "未分配角色"}
												/>
											</List.Item>
										)}
									/>
									<Pagination
										{...usersPage}
										onPage={(page) =>
											void loadUsers(page).catch((reason) =>
												setError(reason instanceof Error ? reason.message : "成员加载失败"),
											)
										}
									/>
								</section>
								<section className="role-editor">
									<h3>{selectedUser ? `${selectedUser.display_name} 的访问范围` : "选择一个用户"}</h3>
									{selectedUser && (
										<>
											<h4>分配角色</h4>
											<Checkbox.Group
												className="permission-checkboxes"
												value={userRoleIds}
												onChange={(keys) =>
													setUserRoleIds((current) => [
														...current.filter((id) => !rolesPage.items.some((role) => role.id === id)),
														...(keys as string[]),
													])
												}
												options={rolesPage.items.map((role) => ({ value: role.id, label: role.name }))}
											/>
											<Pagination
												{...rolesPage}
												onPage={(page) =>
													void loadRoles(page).catch((reason) =>
														setError(reason instanceof Error ? reason.message : "角色加载失败"),
													)
												}
											/>
											<div className="scope-toggle">
												<span>可访问机构下全部客户</span>
												<Switch checked={allProjects} onChange={setAllProjects} />
											</div>
											{!allProjects && (
												<>
													<Table
														size="small"
														rowKey="id"
														pagination={false}
														dataSource={projectsPage.items}
														columns={[
															{ title: "客户", dataIndex: "name" },
															{ title: "域名", dataIndex: "domain" },
														]}
														rowSelection={{
															preserveSelectedRowKeys: true,
															selectedRowKeys: projectIds,
															onChange: (keys) => setProjectIds(keys as string[]),
														}}
													/>
													<Pagination
														{...projectsPage}
														onPage={(page) =>
															void loadProjectsForScope(page).catch((reason) =>
																setError(reason instanceof Error ? reason.message : "客户加载失败"),
															)
														}
													/>
												</>
											)}
											<Button busy={busy} onClick={() => void saveUserAccess()}>
												保存用户授权
											</Button>
										</>
									)}
								</section>
							</div>
						),
					},
				]}
			/>
		</Page>
	);
}
